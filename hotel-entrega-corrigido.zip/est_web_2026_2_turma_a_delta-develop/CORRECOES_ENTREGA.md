# Correções da entrega — Rede Hoteleira

## Implementado nesta versão

- `HotelResponseSchema` agora retorna `cidade` como objeto aninhado, incluindo `id`, `nome`, `estado` e `limite_territorial`.
- A resposta também retorna as comodidades como objetos `{ id, nome }`, em vez de somente UUIDs.
- `HotelRepository` centraliza consultas e persistência e mantém `joinedload` para cidade, associações e comodidades.
- `HotelService` concentra validações e regras de negócio para listar, consultar, criar, atualizar e remover hotéis.
- As rotas HTTP traduzem exceções de domínio em códigos HTTP e não expõem `HTTPException` para a camada de serviço.
- `HotelCreateSchema` aceita `comodidade_ids`; o cadastro e a edição persistem as associações.
- `HoteisRaw.jsx` consulta `/api/v1/cidades` e `/api/v1/hoteis` em paralelo, verifica `response.ok`, trata carregamento/erro e mostra o JSON completo.
- `HoteisRaw` foi integrado ao final da página inicial do site.
- `HomePage.jsx` agora usa o roteador próprio do projeto, compatível com `App.jsx`.
- O detalhe do hotel apresenta os nomes das comodidades recebidas pela API.
- A carga inicial de demonstração preenche diárias com valores de exemplo quando o quarto ainda não tem preço ou está com preço zero.
- Foram removidos arquivos antigos sem uso, duplicados por responsabilidade ou incompatíveis com o roteador atual: páginas administrativas legadas, tutorial sem rota/implementação correspondente, `StacksTable` sem uso e schemas antigos não referenciados.

## Validações executadas no ambiente de preparação

- `python -m compileall -q services/core-service/app`: aprovado.
- Importação de `HotelService`, `HotelRepository` e schemas: aprovada.
- Validação Pydantic de resposta com cidade aninhada e comodidades: aprovada.

## Validações que precisam ser executadas no Codespace

O ambiente de preparação não tinha Docker nem as dependências completas do frontend/backend (a instalação `npm ci` não terminou; o pacote Python `motor` não estava instalado). Portanto, não foi possível declarar build, testes integrados ou execução real do Docker como aprovados.

No Codespace, execute:

```bash
npm ci --prefix frontend
npm run build --prefix frontend
npm run lint --prefix frontend

docker compose exec core-service poetry run pytest -q

docker compose config
docker compose up --build -d
docker compose ps
docker compose logs --tail=100 core-service frontend
```

Abra `http://localhost:5173`, role até “Conferência dos dados da API” e confira os dois blocos JSON. O hotel deve conter `cidade` como objeto, e `comodidades` como lista de objetos.

## Configuração do ambiente

Crie `.env` a partir de `.env.example`. Preencha senhas fortes e mantenha os valores consistentes entre `MONGO_ROOT_PASSWORD` e `MONGODB_URL`, e entre `RABBITMQ_PASSWORD` e `RABBITMQ_URL`. Para MongoDB no Docker, o host da URL deve ser `mongodb`, não `localhost`; use `authSource=admin`.

Não apague volumes Docker para corrigir autenticação sem antes confirmar que os dados podem ser descartados: os usuários e senhas de bancos já inicializados ficam persistidos nos volumes.

## Verificação funcional da trilha

1. Abra `http://localhost:8000/docs`.
2. Faça login com um usuário administrador e autorize o Swagger com o Bearer token.
3. Cadastre uma cidade, se necessário.
4. Cadastre um hotel associado à cidade.
5. Recarregue `http://localhost:5173`.
6. Confirme que o hotel aparece no JSON e que `cidade` contém o objeto completo.
7. Pare temporariamente o serviço com `docker compose stop core-service`; a seção JSON deve exibir mensagem de erro e opção para tentar novamente.
8. Reinicie com `docker compose start core-service`.
